import React from 'react';
import { Lightbulb, TrendingDown, Package } from 'lucide-react';
import { colors } from '../theme/colors';

interface Recommendation {
  type: 'cost' | 'packaging' | 'shipping';
  message: string;
}

interface AIRecommendationsProps {
  recommendations: Recommendation[];
}

export function AIRecommendations({ recommendations }: AIRecommendationsProps) {
  if (!recommendations.length) return null;

  const getIcon = (type: Recommendation['type']) => {
    switch (type) {
      case 'cost':
        return <TrendingDown className="h-5 w-5" style={{ color: colors.secondary.main }} />;
      case 'packaging':
        return <Package className="h-5 w-5" style={{ color: colors.secondary.main }} />;
      default:
        return <Lightbulb className="h-5 w-5" style={{ color: colors.secondary.main }} />;
    }
  };

  return (
    <div className="bg-white/90 rounded-lg p-4 shadow-sm border border-gray-100">
      <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center gap-2">
        <Lightbulb className="h-5 w-5" style={{ color: colors.secondary.main }} />
        Recomendaciones IA
      </h3>
      <div className="space-y-3">
        {recommendations.map((rec, index) => (
          <div key={index} className="flex items-start gap-3 p-3 bg-gray-50 rounded-md">
            {getIcon(rec.type)}
            <p className="text-sm text-gray-700">{rec.message}</p>
          </div>
        ))}
      </div>
    </div>
  );
}