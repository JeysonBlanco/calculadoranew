import React, { useEffect, useRef } from 'react';
import { Package } from '../types/calculator';
import { colors } from '../theme/colors';

interface PackageVisualizationProps {
  packages: Package[];
}

export function PackageVisualization({ packages }: PackageVisualizationProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw packages
    packages.forEach((pkg, index) => {
      const { length, width, height } = pkg;
      if (typeof length !== 'number' || typeof width !== 'number' || typeof height !== 'number') return;

      // Calculate scale to fit canvas
      const maxDimension = Math.max(length, width, height);
      const scale = (canvas.width * 0.8) / maxDimension;

      // Calculate center position
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;

      // Draw isometric box
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.scale(scale, scale);
      
      // Set colors
      ctx.strokeStyle = colors.primary.main;
      ctx.fillStyle = `${colors.secondary.main}20`;

      // Draw front face
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(width, 0);
      ctx.lineTo(width, -height);
      ctx.lineTo(0, -height);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Draw top face
      ctx.beginPath();
      ctx.moveTo(0, -height);
      ctx.lineTo(width, -height);
      ctx.lineTo(width + length/2, -height - length/4);
      ctx.lineTo(length/2, -height - length/4);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Draw side face
      ctx.beginPath();
      ctx.moveTo(width, 0);
      ctx.lineTo(width + length/2, -length/4);
      ctx.lineTo(width + length/2, -height - length/4);
      ctx.lineTo(width, -height);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.restore();
    });
  }, [packages]);

  return (
    <div className="bg-white/90 rounded-lg p-4 shadow-sm border border-gray-100">
      <h3 className="text-lg font-medium text-gray-900 mb-4">
        Visualización en Tiempo Real
      </h3>
      <canvas
        ref={canvasRef}
        width={400}
        height={300}
        className="w-full h-auto bg-white rounded-md"
      />
    </div>
  );
}