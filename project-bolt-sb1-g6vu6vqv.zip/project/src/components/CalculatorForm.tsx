import React from 'react';
import { CargoType, Dimensions, Package, LengthUnit } from '../types/calculator';
import { PackageForm } from './PackageForm';
import { Plus, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { colors } from '../theme/colors';
import { AIRecommendations } from './AIRecommendations';
import { PackageVisualization } from './PackageVisualization';
import { useAIValidation } from '../hooks/useAIValidation';
import { useSavedCalculations } from '../hooks/useSavedCalculations';

interface CalculatorFormProps {
  onSubmit: (dimensions: Dimensions) => void;
}

const defaultPackage: Package = {
  length: '',
  width: '',
  height: '',
  weight: '',
  pieces: 1,
  unit: 'cm' as LengthUnit,
  nonStackable: false
};

export function CalculatorForm({ onSubmit }: CalculatorFormProps) {
  const [formData, setFormData] = React.useState<Dimensions>({
    packages: [{ ...defaultPackage }],
    cargoType: 'Marítimo'
  });

  const { recommendations, validationStatus } = useAIValidation(formData);
  const { saveCalculation } = useSavedCalculations();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveCalculation(formData);
    onSubmit(formData);
  };

  const handlePackageChange = (index: number, pkg: Package) => {
    const newPackages = [...formData.packages];
    newPackages[index] = pkg;
    setFormData(prev => ({ ...prev, packages: newPackages }));
  };

  const handleAddPackage = () => {
    setFormData(prev => ({
      ...prev,
      packages: [...prev.packages, { ...defaultPackage }]
    }));
  };

  const handleRemovePackage = (index: number) => {
    setFormData(prev => ({
      ...prev,
      packages: prev.packages.filter((_, i) => i !== index)
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="mb-4">
        <label htmlFor="cargoType" className="block text-lg font-medium text-gray-900 mb-2">
          Modalidad de Embarque
        </label>
        <select
          id="cargoType"
          value={formData.cargoType}
          onChange={(e) => setFormData(prev => ({ ...prev, cargoType: e.target.value as CargoType }))}
          className="w-full px-4 py-3 bg-white/90 border border-gray-300 rounded-lg text-lg hover:shadow-[0_0_10px_rgba(42,212,174,0.3)] focus:ring-[#2AD4AE] focus:border-[#2AD4AE] transition-all"
          required
        >
          <option value="Marítimo">Marítimo</option>
          <option value="Aéreo">Aéreo</option>
          <option value="Courier">Courier</option>
        </select>
      </div>

      {/* AI Validation Status */}
      {validationStatus && (
        <div className={`p-4 rounded-lg flex items-center gap-3 ${
          validationStatus.type === 'warning' ? 'bg-amber-50 text-amber-700' : 'bg-green-50 text-green-700'
        }`}>
          {validationStatus.type === 'warning' ? (
            <AlertTriangle className="h-5 w-5 flex-shrink-0" />
          ) : (
            <CheckCircle2 className="h-5 w-5 flex-shrink-0" />
          )}
          <p className="text-sm">{validationStatus.message}</p>
        </div>
      )}

      {/* Package Visualization */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
      <div className="space-y-4">
        {formData.packages.map((pkg, index) => (
          <PackageForm
            key={index}
            package={pkg}
            index={index}
            onChange={handlePackageChange}
            onRemove={handleRemovePackage}
            showRemove={formData.packages.length > 1}
          />
        ))}
      </div>
        </div>
        <div className="space-y-4">
          <PackageVisualization packages={formData.packages} />
          <AIRecommendations recommendations={recommendations} />
        </div>
      </div>

      <button
        type="button"
        onClick={handleAddPackage}
        className="w-full flex items-center justify-center gap-2 py-3 px-4 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:text-gray-900 hover:border-gray-400 transition-colors"
      >
        <Plus className="h-5 w-5" />
        Agregar otro paquete
      </button>

      <button
        type="submit"
        style={{ backgroundColor: colors.primary.main }}
        className="w-full text-white py-3 px-4 rounded-lg text-lg font-medium hover:opacity-90 transition-opacity"
      >
        Calcular
      </button>
    </form>
  );
}