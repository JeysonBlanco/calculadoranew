import React from 'react';
import { Link, useLocation } from 'react-router-dom';

interface MenuItem {
  label: string;
  href: string;
}

const menuItems: MenuItem[] = [
  { label: 'Servicios', href: '/services' },
  { label: 'Cotizar', href: '/quote' },
  { label: 'Rastreo', href: '/tracking' },
  { label: 'Contacto', href: '/contact' },
];

export function Header() {
  const location = useLocation();

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <nav className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <img
              src="/images/Segucargo®-logo-secundaria Azul con color (2).png"
              alt="Segucargo Logo"
              className="h-8 sm:h-10 md:h-12 w-auto transition-all duration-200"
            />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden sm:flex items-center space-x-6">
            {menuItems.map((item) => (
              <Link
                key={item.label}
                to={item.href}
                className={`px-3 py-2 text-sm font-medium transition-all relative hover:text-[#2AD4AE] ${
                  location.pathname === item.href
                    ? 'text-[#001E5D]'
                    : 'text-gray-600'
                }`}
              >
                {item.label}
                <span 
                  className={`absolute bottom-0 left-0 w-full h-0.5 bg-[#2AD4AE] transform transition-transform duration-200 ${
                    location.pathname === item.href ? 'scale-x-100' : 'scale-x-0'
                  }`}
                />
              </Link>
            ))}
          </div>
        </nav>
      </div>
    </header>
  );
}