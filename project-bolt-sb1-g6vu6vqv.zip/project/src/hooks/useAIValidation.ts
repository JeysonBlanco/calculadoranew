import { useState, useEffect } from 'react';
import { Dimensions } from '../types/calculator';

interface ValidationStatus {
  type: 'warning' | 'success';
  message: string;
}

interface AIValidationResult {
  recommendations: Array<{
    type: 'cost' | 'packaging' | 'shipping';
    message: string;
  }>;
  validationStatus: ValidationStatus | null;
}

export function useAIValidation(formData: Dimensions): AIValidationResult {
  const [result, setResult] = useState<AIValidationResult>({
    recommendations: [],
    validationStatus: null
  });

  useEffect(() => {
    // Simulate AI validation logic
    const validateDimensions = () => {
      const recommendations = [];
      let validationStatus = null;

      formData.packages.forEach(pkg => {
        const { length, width, height, weight } = pkg;
        
        // Convert all values to numbers for comparison
        const l = typeof length === 'number' ? length : 0;
        const w = typeof width === 'number' ? width : 0;
        const h = typeof height === 'number' ? height : 0;
        const wt = typeof weight === 'number' ? weight : 0;

        // Volume analysis
        const volume = l * w * h;
        if (volume > 0) {
          const density = wt / volume;

          if (density < 0.1) {
            recommendations.push({
              type: 'packaging',
              message: '¡Optimización posible! El peso parece muy bajo para el volumen. Considera consolidar la carga.'
            });
          }

          // Shipping mode recommendation
          if (volume > 2 && formData.cargoType === 'Aéreo') {
            recommendations.push({
              type: 'cost',
              message: 'Para este volumen, el envío marítimo podría ser más económico.'
            });
          }
        }

        // Non-stackable optimization
        if (pkg.nonStackable && h < (l/2) && h < (w/2)) {
          recommendations.push({
            type: 'packaging',
            message: 'La altura es relativamente baja. Considera opciones de embalaje que permitan apilar.'
          });
        }
      });

      // Overall validation status
      if (recommendations.length > 0) {
        validationStatus = {
          type: 'warning',
          message: 'Hemos detectado algunas oportunidades de optimización.'
        };
      } else {
        validationStatus = {
          type: 'success',
          message: '¡Excelente! Las dimensiones están bien optimizadas.'
        };
      }

      setResult({ recommendations, validationStatus });
    };

    validateDimensions();
  }, [formData]);

  return result;
}