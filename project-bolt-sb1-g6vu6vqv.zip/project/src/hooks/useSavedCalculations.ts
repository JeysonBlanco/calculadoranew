import { useState, useEffect } from 'react';
import { Dimensions } from '../types/calculator';

const STORAGE_KEY = 'savedCalculations';

interface SavedCalculation {
  id: string;
  timestamp: number;
  data: Dimensions;
}

export function useSavedCalculations() {
  const [calculations, setCalculations] = useState<SavedCalculation[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      setCalculations(JSON.parse(saved));
    }
  }, []);

  const saveCalculation = (data: Dimensions) => {
    const newCalculation: SavedCalculation = {
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      data
    };

    const updated = [newCalculation, ...calculations].slice(0, 10); // Keep last 10
    setCalculations(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  const clearHistory = () => {
    setCalculations([]);
    localStorage.removeItem(STORAGE_KEY);
  };

  return {
    calculations,
    saveCalculation,
    clearHistory
  };
}